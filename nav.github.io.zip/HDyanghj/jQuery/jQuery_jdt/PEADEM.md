jQuery焦点图
